"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface WhatsAppUploadProps {
  details: {
    type: string
    quantity: string
    media?: string
    sides?: string
    price?: number
    size?: string
    halfCut?: string
  }
}

export default function WhatsAppUpload({ details }: WhatsAppUploadProps) {
  const [file, setFile] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
    }
  }

  const handleUpload = () => {
    if (file) {
      const detailsText = Object.entries(details)
        .map(([key, value]) => `${key}: ${value}`)
        .join("%0A") // URL-encoded line break

      const message = `New print job:%0A${detailsText}`
      const whatsappUrl = `https://wa.me/919860375558?text=${encodeURIComponent(message)}`

      window.open(whatsappUrl, "_blank")
    }
  }

  return (
    <div className="mt-4 p-4 border rounded-md">
      <h3 className="text-lg font-semibold mb-2">Upload Job to WhatsApp</h3>
      <div className="mb-4">
        <h4 className="font-medium">Job Details:</h4>
        <ul>
          {Object.entries(details).map(([key, value]) => (
            <li key={key}>
              {key}: {value}
            </li>
          ))}
        </ul>
      </div>
      <div className="space-y-2">
        <Label htmlFor="file">Select File</Label>
        <Input id="file" type="file" onChange={handleFileChange} />
      </div>
      <Button onClick={handleUpload} className="mt-4" disabled={!file}>
        Send to WhatsApp
      </Button>
    </div>
  )
}

