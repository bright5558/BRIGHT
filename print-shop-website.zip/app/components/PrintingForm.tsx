"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import WhatsAppUpload from "./WhatsAppUpload"

const mediaOptions = [
  "100 gsm Paper",
  "130 gsm art paper",
  "170 gsm art paper",
  "250 gsm card stock",
  "300 gsm card stock",
  "350 gsm card stock",
  "Sticker sheet",
  "NT sticker sheet",
  "Transparent sticker sheet",
  "Gold Sticker",
  "Silver Sticker",
  "Metallic Silver",
  "Metallic pearl",
]

export default function PrintingForm() {
  const [quantity, setQuantity] = useState("")
  const [media, setMedia] = useState("")
  const [sides, setSides] = useState("single")
  const [halfCut, setHalfCut] = useState(false)
  const [showUpload, setShowUpload] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowUpload(true)
  }

  const isSticker = media.toLowerCase().includes("sticker")

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="quantity">Quantity</Label>
        <Input id="quantity" type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="media">Select Media</Label>
        <Select onValueChange={setMedia} required>
          <SelectTrigger>
            <SelectValue placeholder="Select media" />
          </SelectTrigger>
          <SelectContent>
            {mediaOptions.map((option) => (
              <SelectItem key={option} value={option}>
                {option}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <RadioGroup defaultValue="single" onValueChange={setSides}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="single" id="single" />
          <Label htmlFor="single">Single Side</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="both" id="both" />
          <Label htmlFor="both">Both Sides</Label>
        </div>
      </RadioGroup>
      {isSticker && (
        <div className="flex items-center space-x-2">
          <Checkbox id="halfCut" checked={halfCut} onCheckedChange={(checked) => setHalfCut(checked as boolean)} />
          <Label htmlFor="halfCut">Half Cut (for stickers)</Label>
        </div>
      )}
      <Button type="submit">Submit</Button>
      {showUpload && (
        <WhatsAppUpload
          details={{
            type: "Digital Printing",
            quantity,
            media,
            sides,
            halfCut: isSticker ? (halfCut ? "Yes" : "No") : "N/A",
          }}
        />
      )}
    </form>
  )
}

