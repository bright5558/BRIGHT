"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import WhatsAppUpload from "./WhatsAppUpload"

export default function VisitingCardForm() {
  const [quantity, setQuantity] = useState("")
  const [sides, setSides] = useState("single")
  const [showUpload, setShowUpload] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowUpload(true)
  }

  const price = quantity === "500" ? (sides === "single" ? 1450 : 2200) : sides === "single" ? 1950 : 2700

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="quantity">Quantity</Label>
        <Select onValueChange={setQuantity} required>
          <SelectTrigger>
            <SelectValue placeholder="Select quantity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="500">500</SelectItem>
            <SelectItem value="1000">1000</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <RadioGroup defaultValue="single" onValueChange={setSides}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="single" id="single" />
          <Label htmlFor="single">Single Side</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="both" id="both" />
          <Label htmlFor="both">Both Sides</Label>
        </div>
      </RadioGroup>
      <div>
        <Label>Price: Rs.{price}</Label>
      </div>
      <div>
        <Label>Delivery in 3 to 4 working days</Label>
      </div>
      <Button type="submit">Submit</Button>
      {showUpload && (
        <WhatsAppUpload
          details={{
            type: "Visiting Card",
            quantity,
            sides,
            price,
          }}
        />
      )}
    </form>
  )
}

