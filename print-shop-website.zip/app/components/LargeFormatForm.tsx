"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import WhatsAppUpload from "./WhatsAppUpload"

const mediaOptions = [
  "Vinyl",
  "Translite",
  "Oneway",
  "Backlite",
  "Wallpaper",
  "Star Flex",
  "Canvas",
  "Transparent Vinyl",
]

export default function LargeFormatForm() {
  const [quantity, setQuantity] = useState("")
  const [media, setMedia] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [showUpload, setShowUpload] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowUpload(true)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="quantity">Quantity</Label>
        <Input id="quantity" type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="media">Select Media</Label>
        <Select onValueChange={setMedia} required>
          <SelectTrigger>
            <SelectValue placeholder="Select media" />
          </SelectTrigger>
          <SelectContent>
            {mediaOptions.map((option) => (
              <SelectItem key={option} value={option}>
                {option}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex gap-4">
        <div className="flex-1">
          <Label htmlFor="width">Width (inches)</Label>
          <Input id="width" type="number" value={width} onChange={(e) => setWidth(e.target.value)} required />
        </div>
        <div className="flex-1">
          <Label htmlFor="height">Height (inches)</Label>
          <Input id="height" type="number" value={height} onChange={(e) => setHeight(e.target.value)} required />
        </div>
      </div>
      <Button type="submit">Submit</Button>
      {showUpload && (
        <WhatsAppUpload
          details={{
            type: "Large Format Printing",
            quantity,
            media,
            size: `${width}" x ${height}"`,
          }}
        />
      )}
    </form>
  )
}

