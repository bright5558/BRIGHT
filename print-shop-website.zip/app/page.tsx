import PrintingForm from "./components/PrintingForm"
import LargeFormatForm from "./components/LargeFormatForm"
import VisitingCardForm from "./components/VisitingCardForm"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Home() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Digital Print Shop</h1>
      <Tabs defaultValue="digital">
        <TabsList>
          <TabsTrigger value="digital">Digital Printing</TabsTrigger>
          <TabsTrigger value="large-format">Large Format Printing</TabsTrigger>
          <TabsTrigger value="visiting-card">Visiting Card</TabsTrigger>
        </TabsList>
        <TabsContent value="digital">
          <PrintingForm />
        </TabsContent>
        <TabsContent value="large-format">
          <LargeFormatForm />
        </TabsContent>
        <TabsContent value="visiting-card">
          <VisitingCardForm />
        </TabsContent>
      </Tabs>
    </div>
  )
}

